function increaseCounter() {
    var currentCount = parseInt(document.getElementById('counter').innerText);
    var newCount = currentCount + 1 + " like(s) ";
    var howmany = "";
    document.getElementById('counter').innerText = newCount + howmany;
}

function increaseCounter1() {
    var currentCount = parseInt(document.getElementById('counter1').innerText);
    var newCount = currentCount + 1 + " like(s) ";
    var howmany = "";
    document.getElementById('counter1').innerText = newCount + howmany;
}

function increaseCounter2() {
    var currentCount = parseInt(document.getElementById('counter2').innerText);
    var newCount = currentCount + 1 + " like(s) ";
    var howmany = "";
    document.getElementById('counter2').innerText = newCount + howmany;
}